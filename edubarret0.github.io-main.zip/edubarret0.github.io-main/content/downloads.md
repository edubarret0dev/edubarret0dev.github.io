# Downloads

Acesse materiais, apresentações e arquivos para download:

- [Currículo atualizado (PDF)](#)
- [Apresentação DevOps (PPT)](#)
- [E-book: Boas práticas em desenvolvimento](#)
