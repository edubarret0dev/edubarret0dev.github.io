# Serviços

Conheça os serviços oferecidos por Eduardo Barreto:

- **Consultoria DevOps:** Implantação de pipelines, automação e cultura DevOps.
- **Desenvolvimento Web:** Criação de sites, sistemas e APIs sob demanda.
- **Treinamentos:** Capacitação em ferramentas, metodologias ágeis e boas práticas.
