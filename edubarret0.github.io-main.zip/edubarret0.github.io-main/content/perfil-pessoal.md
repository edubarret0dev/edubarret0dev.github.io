
- **Localização:** Brasil
- **Email:** edubarret0dev@gmail.com
- **GitHub:** [github.com/edubarret0](https://github.com/edubarret0)

## Sobre mim
Sou apaixonado por tecnologia, inovação e automação. Tenho experiência em desenvolvimento de software, engenharia de sistemas e práticas DevOps. Busco sempre aprender e compartilhar conhecimento.

## Conquistas
- 🏆 Destaque
- ⭐ Pro

## Redes Sociais
- [Email](mailto:edubarret0dev@gmail.com)
- [X](https://x.com/eduBarret0)
- [Instagram](https://www.instagram.com/engedubarreto/?hl=pt-br)
- [Facebook](https://www.facebook.com/eduardo.barreto.9277583)
- [YouTube](https://www.youtube.com/channel/UCKlvq21jNbikjJzZiufVNwQ?view_as=subscriber)
- [LinkedIn](https://www.linkedin.com/in/eduardo-barreto-244575b4/)
