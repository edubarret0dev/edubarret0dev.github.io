# Projetos

Confira alguns dos principais projetos desenvolvidos por Eduardo Barreto:

- **Projeto 1:** Sistema de automação DevOps para empresas de tecnologia.
- **Projeto 2:** Plataforma web para gerenciamento de equipes e tarefas.
- **Projeto 3:** API RESTful para integração de sistemas industriais.
